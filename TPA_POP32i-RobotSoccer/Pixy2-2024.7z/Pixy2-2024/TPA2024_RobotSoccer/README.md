https://inex.co.th/store/manual/POP32i-Soccer-Kit-e02-re.pdf
https://inex.co.th/store/manual/POP32i-Sheet230316-re.pdf
https://drive.google.com/drive/folders/15T0xaMcfxVyymEwd9L_D_lbhMvazFrwJ