
#ifndef _POP32_HUSKYLENS_H
#define _POP32_HUSKYLENS_H

#include "HUSKYLENS.h"
#define sigNum 7 + 1  // set fisrt signature as 1
#define sigBuf 10     // size per signature

struct signature
{
  int x;
  int y;
  int width;
  int height;
};

class POP32_Huskylens : public HUSKYLENS 
{
  private:
  
  public:
    POP32_Huskylens();
    ~POP32_Huskylens();
    bool updateBlocks();
    struct signature blockInfo[sigNum][sigBuf];
    int blockSize[sigNum];
    int getNumBlocks();
    
};

POP32_Huskylens::POP32_Huskylens() : HUSKYLENS()
{
  
}

POP32_Huskylens::~POP32_Huskylens()
{
  
}

bool POP32_Huskylens::updateBlocks()
{
  int sigCnt[sigNum] = {0}; 
  int sigIndex;
  requestBlocks();
  
  if (count())
  {
    for (int i=0; i<count(); i++)
    {
      HUSKYLENSResult result = get(i);
      if (i >= sigBuf)  break;  // limit the blocks by the size of buffer
      sigIndex = result.ID;
      blockInfo[sigIndex][sigCnt[sigIndex]].x = result.xCenter;
      blockInfo[sigIndex][sigCnt[sigIndex]].y = result.yCenter;
      blockInfo[sigIndex][sigCnt[sigIndex]].width = result.width;
      blockInfo[sigIndex][sigCnt[sigIndex]].height = result.height;
      sigCnt[sigIndex]++;
    }
    for (int j=1; j<sigNum; j++)
    {
      blockSize[j] = sigCnt[j]; // fill buffer size
    }
    return true;
  } 
  return false;
} 

int POP32_Huskylens::getNumBlocks()
{
  //return sigSize[1] + sigSize[2] + sigSize[3] + sigSize[4] + sigSize[5] + sigSize[6] + sigSize[7] + sigSize[8];
 return count();
 //
}

#endif  // _POP32_PIXY2_H
