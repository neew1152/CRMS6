
#include <POP32.h> 
#include <POP32_Huskylens.h>
POP32_Huskylens huskylens;

void setup() {
  Serial.begin(115200);
  Wire.begin();
  while (!huskylens.begin(Wire)) { 
    oled.text(1, 0, "Begin failed!");  //หากเชื่อมต่อไม่ได้
    oled.show();
    delay(100);
  }
  huskylens.writeAlgorithm(ALGORITHM_COLOR_RECOGNITION); // เลือกโหมดรู้จำสี
  while(!Serial);  //รอเปิด Serial monitor 
  Serial.println("Started!");
}

void loop() {
  if (huskylens.updateBlocks()){
    Serial.print("\nDetected: "); Serial.println(huskylens.getNumBlocks());
    Serial.println("x\ty\twidth\theight");
    for (int i=1; i<=7; i++)  // for loop Blocks
    {
      if(huskylens.blockSize[i]) // Blocks not empty
      {
        Serial.print("-> Blocks: ");  Serial.println(i);
        for (int j=0; j<huskylens.blockSize[i]; j++) // for loop index of Blocks
        {
          Serial.print(huskylens.blockInfo[i][j].x);       Serial.print("\t");
          Serial.print(huskylens.blockInfo[i][j].y);       Serial.print("\t");
          Serial.print(huskylens.blockInfo[i][j].width);   Serial.print("\t");
          Serial.println(huskylens.blockInfo[i][j].height);  
        }
      }
    }
  }
  else
  {
    Serial.println("Not detected");  
  }
}
